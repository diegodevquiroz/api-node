module.exports.EXECUTE_OK = 'Se ejecutó correctamete';
module.exports.EXECUTE_FAIL = 'No ejecutó correctamete';